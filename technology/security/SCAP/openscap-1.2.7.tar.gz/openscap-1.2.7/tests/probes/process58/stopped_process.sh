#!/bin/bash
# Used for command_line test

# STOP itself
kill -SIGSTOP $$
