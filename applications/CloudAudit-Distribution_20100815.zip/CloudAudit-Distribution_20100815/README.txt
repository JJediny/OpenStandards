August 15, 2010

The CloudAudit initial distribution features five elements:

1) The CloudAudit normative specification in .txt format [cloudaudit-specification_draft.txt]
2) The CloudAudit CompliancePacks archive of .xls files which map controls/control objectives to namespaces
   based upon the Cloud Security Alliance Control Matrix [cloudaudit-compliancepacks.zip]
3) The CloudAudit namespaces archive which represents a complete CloudAudit directory tree representation of all CompliancePacks
   with placeholder index.html/manifest.xml created in each directory stub [cloudaudit-namespaces.zip]
4) The CloudAudit Python script pack which automates the creation of the CloudAudit namespaces above 
   [cloudaudit-namespace_creator.zip]
5) This README.txt file

Notes:

* The CloudAudit normative specification is a high-level description of CloudAudit and was submitted to the IETF as a draft. A more technical overview will be provided under separate cover

* The CompliancePacks are provided here in the form of Microsoft Excel documents exported from a library of Google Docs spreadsheets
maintained by CloudAudit volunteers. The basis for these CompliancePacks are the Cloud Security Alliance's Cloud Controls Matrix
which can be found at http://www.cloudsecurityalliance.org/cm.html.

The CompliancePacks map control objectives to specific namespace entities which are contained below and feature NIST SP800-53, PCI DSS, HIPAA, ISO27002 and COBIT compliance frameworks.  Ultimately these directories are where a Cloud Provider will store and
secure the assertions and supporting materials related to each compliance framework or assertion.

These namespaces will be checked in to our SVN repository for change control management at http://code.google.com/p/cloudaudit/

* The CloudAudit namespaces archive is a compressed version of a complete skeletal set of namepsaces listed above.  It is meant to
enable cloud providers, consumers and tool vendors to understand, scope, and architect for what CloudAudit deployments will
require.

* The CloudAudit namespace_creator script is a Python utility which takes an input stream (provided) of CloudAudit namespace
entries and automates the creation of the namespace directories above.

Further enhancements and revisions will be made available.  Scripts that automate the population of namespaces are under
development as are additional features including versioning, versioning and updates, etc.

Updates and current information on the CloudAudit project may be found at http://www.cloudaudit.org and via the CloudAudit
Google group: http://groups.google.com/group/cloudaudit

